export { default } from './Password';
